/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Medida;
import vista.frmVentana;

/**
 *
 * @author A n d r e s
 */
public class Controlador implements ActionListener{
    Medida objM;
    frmVentana objV;

    public Controlador() {
        this.objM = new Medida();
        this.objV = new frmVentana();
        this.objV.getBtnGrupo().add(objV.getRbtnCen());
        this.objV.getBtnGrupo().add(objV.getRbtnDec());
        this.objV.getBtnGrupo().add(objV.getRbtnKil());
        this.objV.getBtnEjecutar().addActionListener(this);
    }
    
    public void iniciar()
    {
        objV.setTitle("Conversor");
        objV.setLocationRelativeTo(null);
        objV.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (objV.getBtnEjecutar()==e.getSource()) {
            objM.setValor(Double.parseDouble(objV.getTxtMedida().getText()));
            if (objV.getRbtnCen().isSelected()) {
                objV.getTxtaResp().append("\n La medida "+objM.getValor()+
                                          "\n en Centímetros es "+ objM.convertirCM()+ "cm" );
                                                 
            }
            else if (objV.getRbtnDec().isSelected()){
                objV.getTxtaResp().append("\n La medida "+objM.getValor()+
                                          "\n en Decímetros es "+ objM.convertirDM()+ "dc");
            }
            else if (objV.getRbtnKil().isSelected()) {
                objV.getTxtaResp().append("\n La medida "+objM.getValor()+
                                          "\n en Kilometros es "+ objM.convertirKM() + "km" );
            }
            }
        }
    }
    
    

