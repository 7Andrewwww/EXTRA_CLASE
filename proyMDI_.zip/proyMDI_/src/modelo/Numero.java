/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author A n d r e s
 */
public class Numero {

    private int valor;

    public Numero(int valor) {
        this.valor = valor;
    }

    public Numero() {
        this.valor = 0;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int suma(int val) {
        return this.valor + val;
    }

    public double potencia(int exp) {
        double potencia = 1;
        for (int i = 0; i <= exp; i++) {
            potencia *= this.valor;
        }
        return potencia;
    }

    @Override
    public String toString() {
        return "Numero{" + "valor=" + valor + '}';
    }

}
