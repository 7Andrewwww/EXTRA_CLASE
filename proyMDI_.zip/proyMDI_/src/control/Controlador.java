/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Numero;
import vista.frmPotencia;
import vista.frmPrincipal;
import vista.frmSuma;

/**
 *
 * @author A n d r e s
 */
public class Controlador implements ActionListener {
    
    frmPrincipal frmInicio;
    frmSuma frmS;
    frmPotencia frmP;
    Numero objN;
    
    public Controlador(frmPrincipal frmInicio, frmSuma frmS, frmPotencia frmP, Numero objN) {
        this.frmInicio = frmInicio;
        this.frmS = frmS;
        this.frmP = frmP;
        this.objN = objN;
    }
    
    public Controlador() {
        frmInicio = new frmPrincipal();
        frmS = new frmSuma();
        frmP = new frmPotencia();
        objN = new Numero();
    }
    
    public void iniciar() {
        frmInicio.setTitle("Ejercicio MDI");
        frmInicio.getOpcSuma().addActionListener(this);
        frmInicio.getOpcPotencia().addActionListener(this);
        frmInicio.getOpcSalir().addActionListener(this);
        frmS.getBtnSumar().addActionListener(this);
        frmP.getBtnPotencia().addActionListener(this);
        frmInicio.setLocationRelativeTo(null);
        frmInicio.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmInicio.getOpcSuma())) {
            frmInicio.getEscritorio().add(frmS);
            frmS.setVisible(true);
        }
        if (e.getSource().equals(frmInicio.getOpcPotencia())) {
            frmInicio.getEscritorio().add(frmP);
            frmP.setVisible(true);
        }
        if (e.getSource().equals(frmInicio.getOpcSalir())) {
            int resp = JOptionPane.showConfirmDialog(frmP, "¿Desea terminar la ejecución?",
                    "Salir", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (resp == JOptionPane.YES_OPTION) {
                frmInicio.dispose();
            }
        }
        if (e.getSource().equals(frmP.getBtnPotencia())) {
            objN.setValor(Integer.parseInt(frmP.getTxtBase().getText()));
            JOptionPane.showMessageDialog(frmP, "La potencia es:" 
                                          + objN.potencia(Integer.parseInt(frmP.getTxtExponente().getText())));
        }
         if (e.getSource().equals(frmS.getBtnSumar())){
             objN.setValor(Integer.parseInt(frmS.getTxtN1().getText()));
             JOptionPane.showMessageDialog(frmP, "La suna es:" 
                                          + objN.suma(Integer.parseInt(frmS.getTxtN2().getText())));
         }
        
    }
    
}
