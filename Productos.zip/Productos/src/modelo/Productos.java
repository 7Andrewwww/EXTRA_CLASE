/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author A n d r e s
 */
public class Productos {

    protected String cod, nom;
    protected double precio;
    protected int cantidad;

    public Productos(String cod, String nom, double precio, int cantidad) {
        this.cod = cod;
        this.nom = nom;
        this.precio = precio;
        this.cantidad = cantidad;
    }

    public Productos() {
        this.cod = "";
        this.nom = "";
        this.precio = 0;
        this.cantidad = 0;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double IVA() {
        double IVA = 0.21;
        return precio * cantidad * IVA;
    }

    public double ValorPago() {
        return (precio * cantidad) + IVA();
    }

    @Override
    public String toString() {
        return "\n Productos" + "\n cod=" + cod + ", \n nom=" + nom + ", \n precio=" + precio + ", \n cantidad=" + cantidad + '}';
    }
    

}
