/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author A n d r e s
 */
public class ListaProductos {
    private ArrayList<Productos> ListaP;
    public ListaProductos(){
        this.ListaP=new ArrayList<Productos>();
    }

    public ArrayList<Productos> getListaP() {
        return ListaP;
    }

    public void setListaP(ArrayList<Productos> ListaP) {
        this.ListaP = ListaP;
    }
    

    @Override
    public String toString() {
        String productos="";
        for (int i = 0; i < ListaP.size(); i++) {
            productos+= "Producto " + (i+1) + " :" + ListaP.get(i).toString() + 
                    "\n Pago " + ListaP.get(i).ValorPago();
        }
        return "Lista Productos: \n" + productos;
    }
    
}
