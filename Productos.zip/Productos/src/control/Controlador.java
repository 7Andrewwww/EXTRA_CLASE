/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelo.ListaProductos;
import modelo.Productos;
import vista.Ventana;

/**
 *
 * @author A n d r e s
 */
public class Controlador implements ActionListener {

    ListaProductos ListaP;
    Ventana frmP;

    public Controlador() {
        this.ListaP = new ListaProductos();
        this.frmP = new Ventana();
        this.frmP.getBtnRegistrar().addActionListener(this);

    }

    public void iniciar() {
        frmP.setTitle("Productos con JTable");
        frmP.setLocationRelativeTo(null);
        frmP.getTxtCod().setEnabled(false);
        frmP.getBtnRegistrar().addActionListener(this);
        frmP.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(frmP.getBtnRegistrar())) {
            Productos objP = new Productos();
            objP.setNom(frmP.getTxtNom().getText());
            objP.setPrecio(Double.parseDouble(frmP.getTxtPre().getText()));
            objP.setCantidad(Integer.parseInt(frmP.getTxtCan().getText()));
            frmP.getTxtCod().setText(objP.getCod());
            ListaP.getListaP().add(objP);
            agregarProductos(objP, frmP.getTblDatos());
            JOptionPane.showMessageDialog(frmP, objP.toString() + 
                    "\n Sub Total: " + objP.ValorPago() + "\n IVA: " + objP.IVA());

        }
    }

    public void agregarProductos(Productos prod, JTable tabla) {
        Object datos[] = {prod.getCod(), prod.getNom(), prod.getPrecio(),
            prod.getCantidad(), prod.ValorPago()};
        DefaultTableModel plantilla = (DefaultTableModel) tabla.getModel();
        plantilla.addRow(datos);
    }

}
