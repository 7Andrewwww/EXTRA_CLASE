/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author A n d r e s
 */
public class Medida {

    private double valor;

    public Medida(double valor) {
        this.valor = valor;
    }

    public Medida() {
        this.valor = 0;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    @Override
    public String toString() {
        return "Medida{" + "valor=" + valor + '}';
    }

    public double convertirCM() {
        return this.valor * 100;
    }

    public double convertirDM() {
        return this.valor * 10;
    }

    public double convertirKM() {
        return this.valor / 1000;
    }
}
