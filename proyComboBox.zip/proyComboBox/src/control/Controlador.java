/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.Medida;
import vista.frmVentana;

/**
 *
 * @author A n d r e s
 */
public class Controlador implements ActionListener {

    Medida objM;
    frmVentana objV;

    public Controlador() {
        this.objM = new Medida();
        this.objV = new frmVentana();
        this.objV.getBtnEjecutar().addActionListener(this);
    }

    public void iniciar() {
        objV.setTitle("Conversor");
        objV.setLocationRelativeTo(null);
        objV.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (objV.getBtnEjecutar() == e.getSource()) {
            objM.setValor(Double.parseDouble(objV.getTxtMedida().getText()));
            switch (objV.getCmbTipoM().getSelectedIndex()) {
                case 0 -> {
                    objV.getTxtaResp().append("\n La medida en centímetros es :" + objM.convertirCM());
                }
                case 1 -> {
                    objV.getTxtaResp().append("\n La medida en decímetros es :" + objM.convertirDM());

                }
                case 2 -> {
                    objV.getTxtaResp().append("\n La medida en kilometros es :" + objM.convertirKM());
                }
            }

        }
    }
}
